package com.example.teachandlearn.Student.Form1.Documents.Agriculture;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.teachandlearn.R;

public class Form1AgricultureReadNotesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form1_agriculture_read_notes);

        // You can add additional logic here if needed
    }
}
