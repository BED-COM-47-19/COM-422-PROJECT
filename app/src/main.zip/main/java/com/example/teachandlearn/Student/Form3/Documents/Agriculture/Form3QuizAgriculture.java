package com.example.teachandlearn.Student.Form3.Documents.Agriculture;

import java.io.Serializable;

public class Form3QuizAgriculture implements Serializable {
    private String questionText;
    private String optionA, optionB, optionC, optionD;
    private String correctAnswer;
    private String userAnswer;  // New field to store the user's answer



    public Form3QuizAgriculture(String questionText, String optionA, String optionB, String optionC, String optionD, String correctAnswer) {
        this.questionText = questionText;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.correctAnswer = correctAnswer;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String getOptionA() {
        return optionA;
    }

    public String getOptionB() {
        return optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public String getOptionD() {
        return optionD;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public String getUserAnswer() {
        return userAnswer;
    }

    public void setUserAnswer(String userAnswer) {
        this.userAnswer = userAnswer;
    }
}
